package com.example.freelook.mixin;

import com.example.freelook.FreeLookMod;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {

    /** Пока зажата клавиша, мышь двигает только камеру, а не игрока. */
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void freelook$turn(double yRot, double xRot, CallbackInfo ci) {
        if ((Object) this instanceof LocalPlayer && FreeLookMod.holding) {
            FreeLookMod.addLook(yRot, xRot);
            ci.cancel();
        }
    }
}
