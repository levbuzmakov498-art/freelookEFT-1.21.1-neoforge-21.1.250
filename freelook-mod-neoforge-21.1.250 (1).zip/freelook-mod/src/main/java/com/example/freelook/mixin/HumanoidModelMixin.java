package com.example.freelook.mixin;

import com.example.freelook.FreeLookMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Вид от третьего лица: голова модели игрока следует за свободной камерой,
 * тело, руки и оружие остаются на месте (меняется только поворот головы).
 */
@Mixin(HumanoidModel.class)
public abstract class HumanoidModelMixin {

    @Shadow public ModelPart head;
    @Shadow public ModelPart hat;

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void freelook$head(LivingEntity entity, float limbSwing, float limbSwingAmount,
                               float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (!FreeLookMod.isActive() || entity != Minecraft.getInstance().player) return;
        Pose pose = entity.getPose();
        if (pose != Pose.STANDING && pose != Pose.CROUCHING) return;

        float yaw = head.yRot + FreeLookMod.currentYaw * Mth.DEG_TO_RAD;
        head.yRot = Mth.clamp(yaw, -Mth.HALF_PI, Mth.HALF_PI);           // не выкручиваем шею дальше 90°
        head.xRot = FreeLookMod.currentAbsPitch * Mth.DEG_TO_RAD;        // взгляд головы = наклон камеры
        hat.copyFrom(head);
    }
}
