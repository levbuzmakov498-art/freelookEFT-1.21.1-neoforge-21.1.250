package com.example.freelook.mixin;

import com.example.freelook.FreeLookMod;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * Задаёт углы камеры прямо в Camera.setup(), ДО расчёта позиции камеры.
 * Благодаря этому от третьего лица камера корректно облетает игрока по орбите
 * (а не просто поворачивается на месте), с учётом столкновений с блоками.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Shadow private Entity entity;

    /** Один раз за кадр обновляем сглаживание. */
    @Inject(method = "setup", at = @At("HEAD"))
    private void freelook$frame(BlockGetter level, Entity entity, boolean detached,
                                boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
        if (entity == Minecraft.getInstance().player) {
            FreeLookMod.frameUpdate();
        }
    }

    /** Подменяем исходные углы: yaw = тело + смещение, pitch = абсолютный от горизонта. */
    @ModifyArgs(method = "setup",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setRotation(FF)V", ordinal = 0))
    private void freelook$angles(Args args) {
        if (!FreeLookMod.isActive() || this.entity != Minecraft.getInstance().player) return;
        float yaw = args.get(0);
        args.set(0, yaw + FreeLookMod.currentYaw);
        args.set(1, FreeLookMod.currentAbsPitch);
    }
}
