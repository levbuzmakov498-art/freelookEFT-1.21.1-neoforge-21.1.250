package com.example.freelook;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Совместимость с TACZ через рефлексию — мод собирается БЕЗ jar-файла TACZ
 * и не падает, если названия классов в твоей версии TACZ отличаются.
 *
 * Оружие НЕ блокируется. Любое действие с оружием (выстрел, перезарядка, удар,
 * смена режима огня, ЛКМ/ПКМ — стрельба и прицел) просто отключает свободный обзор,
 * после чего камера и руки плавно возвращаются в обычное состояние.
 */
public final class TaczCompat {
    private static final Logger LOG = LoggerFactory.getLogger("FreeLook/TACZ");

    private static final String[] ACTION_EVENTS = {
            "com.tacz.guns.api.event.common.GunShootEvent",
            "com.tacz.guns.api.event.common.GunReloadEvent",
            "com.tacz.guns.api.event.common.GunMeleeEvent",
            "com.tacz.guns.api.event.common.GunFireSelectEvent"
    };

    private static Class<?> gunInterface;

    private TaczCompat() {}

    @SuppressWarnings("unchecked")
    public static void register() {
        try {
            gunInterface = Class.forName("com.tacz.guns.api.item.IGun");
        } catch (Throwable t) {
            LOG.warn("TACZ IGun not found, gun-in-hand check disabled: {}", t.toString());
        }

        for (String name : ACTION_EVENTS) {
            try {
                Class<?> c = Class.forName(name);
                if (!Event.class.isAssignableFrom(c)) {
                    LOG.warn("{} is not a NeoForge event, skipped", name);
                    continue;
                }
                // receiveCanceled = true: реагируем даже если событие отменил кто-то ещё
                NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, true,
                        (Class<Event>) c, TaczCompat::onGunAction);
            } catch (Throwable t) {
                LOG.warn("TACZ event {} not available: {}", name, t.toString());
            }
        }
    }

    /** Событие оружия: свободный режим выключается, само действие не трогаем. */
    private static void onGunAction(Event e) {
        // события серверного потока (встроенный сервер) нас не касаются
        if (Minecraft.getInstance().isSameThread()) {
            FreeLookMod.cancelFreeLook();
        }
    }

    /** Держит ли игрок в основной руке оружие TACZ. */
    public static boolean isHoldingGun(Player player) {
        return gunInterface != null && gunInterface.isInstance(player.getMainHandItem().getItem());
    }
}
