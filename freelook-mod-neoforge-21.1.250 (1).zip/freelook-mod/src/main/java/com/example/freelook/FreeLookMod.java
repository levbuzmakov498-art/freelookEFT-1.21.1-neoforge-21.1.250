package com.example.freelook;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.CameraType;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

@Mod(value = FreeLookMod.MODID, dist = Dist.CLIENT)
public class FreeLookMod {
    public static final String MODID = "freelook";

    // ---- Ограничения (градусы) ----
    /** Максимум влево/вправо от направления тела (в каждую сторону). */
    public static final float MAX_YAW = 70f;
    /** Максимум вверх от ГОРИЗОНТА (0°). */
    public static final float MAX_PITCH_UP = 60f;
    /** Максимум вниз от ГОРИЗОНТА (0°). Применяется сразу: если игрок смотрит ниже — камера плавно приподнимется. */
    public static final float MAX_PITCH_DOWN = 55f;

    // ---- Плавность (чем больше число — тем быстрее, 1/сек) ----
    public static final float FOLLOW_SPEED = 22f; // следование за мышью
    public static final float RETURN_SPEED = 11f; // возврат камеры после отпускания клавиши
    public static final float HAND_SPEED_ENTER = 3.5f;  // руки медленно уходят в 0° (горизонт)
    public static final float HAND_SPEED_RETURN = 9f;   // руки возвращаются к взгляду игрока
    /** Общая чувствительность мыши в свободном режиме (1.0 = как в ванили). Сглаживание от неё не зависит. */
    public static final float SENSITIVITY_MULT = 0.55f;
    public static final float MOUSE_FACTOR = 0.15f * SENSITIVITY_MULT;

    // ---- Руки при свободной камере ----
    /** Насколько руки подтягиваются к камере при взгляде вниз (блоки, вдоль взгляда). */
    public static final float HAND_PULL_Z = 0.42f;
    /** Насколько руки опускаются к телу при взгляде вниз (блоки). */
    public static final float HAND_PULL_Y = 0.14f;
    /**
     * Насколько руки реагируют на опускание головы ВНИЗ от горизонта
     * (1.0 = полностью стоят на месте в мире, меньше = руки меньше «ездят» по экрану).
     * Выше горизонта руки работают как раньше (коэффициент 1.0).
     */
    public static final float HAND_PITCH_FOLLOW = 0.55f;

    /** Угол для матрицы рук: ниже горизонта — с ослаблением, выше горизонта — как раньше. */
    public static float handAngle(float pitch) {
        return pitch > 0f ? pitch * HAND_PITCH_FOLLOW : pitch;
    }

    // ---- Состояние ----
    public static boolean holding = false;   // клавиша зажата
    public static boolean active = false;    // камера смещена (включая плавный возврат)
    private static boolean returning = false;
    /** После отмены (стрельба/прицел) не включаем свободный обзор, пока не отпустят клавишу. */
    private static boolean locked = false;

    /** Сглаженное смещение по горизонтали относительно тела. */
    public static float currentYaw;
    /** Сглаженный АБСОЛЮТНЫЙ наклон камеры (0° = горизонт, +вниз), не относительный. */
    public static float currentAbsPitch;

    /**
     * Наклон, под которым «нарисованы» руки. Сразу после включения = взгляд игрока,
     * затем плавно уходит в 0° (горизонт) — руки встают в обычное положение, как в Anomaly.
     */
    public static float currentHandRef;
    /** 0..1 — насколько руки подтянуты к камере (растёт, чем ниже опущена голова). */
    public static float currentPull;
    /**
     * 0..1 — насколько подавляются чужие данные камеры (анимации TACZ: осмотр оружия, тряска и т.п.).
     * Пока свободный обзор зажат = 1 (камера принимает только наши данные),
     * после отпускания плавно уходит в 0, и чужие анимации продолжаются.
     */
    public static float cameraSuppress;

    private static float targetYaw, targetAbsPitch;
    private static long lastFrameNanos;

    public static final KeyMapping KEY = new KeyMapping(
            "key.freelook.hold", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_LEFT_ALT, "key.categories.freelook");

    public FreeLookMod(IEventBus modBus) {
        modBus.addListener(FreeLookMod::registerKeys);
        NeoForge.EVENT_BUS.register(ClientEvents.class);
        modBus.addListener((FMLClientSetupEvent e) -> {
            if (ModList.get().isLoaded("tacz")) {
                e.enqueueWork(TaczCompat::register);
            }
        });
    }

    private static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(KEY);
    }

    public static boolean isActive() {
        return active;
    }

    /**
     * Взаимодействие с оружием (выстрел, прицел, перезарядка...) — свободный режим
     * сразу отключается и плавно возвращается в обычное состояние.
     * Само действие с оружием при этом НЕ блокируется.
     */
    public static void cancelFreeLook() {
        if (!active) return;
        locked = true;     // не включать снова, пока клавиша не будет отпущена
        holding = false;   // мышь снова поворачивает игрока
        returning = true;  // плавный возврат
    }

    /** Вызывается из миксина вместо поворота игрока. */
    public static void addLook(double dYaw, double dPitch) {
        var player = Minecraft.getInstance().player;
        if (player == null) return;
        // Лимиты строго от горизонта (0°), без учёта угла игрока
        float lo = -MAX_PITCH_UP;
        float hi = MAX_PITCH_DOWN;
        targetYaw = Mth.clamp(targetYaw + (float) dYaw * MOUSE_FACTOR, -MAX_YAW, MAX_YAW);
        targetAbsPitch = Mth.clamp(targetAbsPitch + (float) dPitch * MOUSE_FACTOR, lo, hi);
    }

    /** Вызывается из CameraMixin один раз за кадр, перед расчётом камеры. */
    public static void frameUpdate() {
        if (!active) return;
        var player = Minecraft.getInstance().player;
        if (player == null) return;
        updateSmoothing(player.getXRot());
    }

    /** Сглаживание к целевым значениям. */
    private static void updateSmoothing(float basePitch) {
        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : Mth.clamp((now - lastFrameNanos) / 1.0e9f, 0f, 0.1f);
        lastFrameNanos = now;

        if (returning) { // цель — центр: 0° по горизонтали и текущий угол взгляда игрока
            targetYaw = 0f;
            targetAbsPitch = basePitch;
        }
        float refTarget = returning ? basePitch : 0f;           // руки: горизонт, на выходе — обратно
        float pullTarget = returning ? 0f : pullFor(currentAbsPitch);
        float k = 1f - (float) Math.exp(-(returning ? RETURN_SPEED : FOLLOW_SPEED) * dt);
        float kHand = 1f - (float) Math.exp(-(returning ? HAND_SPEED_RETURN : HAND_SPEED_ENTER) * dt);
        cameraSuppress += ((returning ? 0f : 1f) - cameraSuppress) * k;
        currentHandRef += (refTarget - currentHandRef) * kHand;
        currentPull += (pullTarget - currentPull) * kHand;
        currentYaw += (targetYaw - currentYaw) * k;
        currentAbsPitch += (targetAbsPitch - currentAbsPitch) * k;
        // Камера физически не может перевернуться через себя
        currentAbsPitch = Mth.clamp(currentAbsPitch, -90f, 90f);

        if (returning && Math.abs(currentYaw) < 0.3f && Math.abs(currentAbsPitch - basePitch) < 0.3f
                && Math.abs(currentHandRef - basePitch) < 0.3f && currentPull < 0.01f
                && cameraSuppress < 0.02f) {
            active = false;
            returning = false;
            currentYaw = 0f;
            currentPull = 0f;
            cameraSuppress = 0f;
        }
    }

    /** Чем ниже опущена камера от горизонта, тем ближе руки (плавная кривая 0..1). */
    private static float pullFor(float absPitch) {
        float t = Mth.clamp(absPitch / MAX_PITCH_DOWN, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    public static class ClientEvents {
        @SubscribeEvent
        public static void tick(ClientTickEvent.Post e) {
            Minecraft mc = Minecraft.getInstance();
            var player = mc.player;

            boolean keyDown = KEY.isDown();
            if (!keyDown) locked = false;
            boolean want = player != null && mc.screen == null && keyDown && !locked
                    && mc.options.getCameraType() != CameraType.THIRD_PERSON_FRONT;

            if (want && !holding) { // нажали клавишу
                if (!active) { // старт «с нуля»: камера = текущий взгляд игрока
                    currentYaw = targetYaw = 0f;
                    currentAbsPitch = player.getXRot();
                    // ограничения действуют сразу: если смотрим ниже лимита — голову плавно приподнимет
                    targetAbsPitch = Mth.clamp(currentAbsPitch, -MAX_PITCH_UP, MAX_PITCH_DOWN);
                    currentHandRef = player.getXRot();
                    currentPull = 0f;
                    cameraSuppress = 0f; // быстро вырастет до 1 — чужие данные камеры отключатся
                } else {       // нажали снова во время возврата — продолжаем плавно
                    targetYaw = currentYaw;
                    targetAbsPitch = Mth.clamp(currentAbsPitch, -MAX_PITCH_UP, MAX_PITCH_DOWN);
                }
                active = true;
                returning = false;
            } else if (!want && holding) { // отпустили клавишу
                returning = true;
            }
            holding = want;

            if (player == null && active) { // вышли из мира
                active = false;
                returning = false;
            }

            // ЛКМ/ПКМ с оружием TACZ в руке (выстрел, прицел) — выходим из свободного режима
            if (active && player != null && mc.screen == null && TaczCompat.isHoldingGun(player)
                    && (mc.options.keyAttack.isDown() || mc.options.keyUse.isDown())) {
                cancelFreeLook();
            }
        }

        /**
         * Итоговые углы камеры. Идём ПОСЛЕДНИМИ (LOWEST).
         *
         * Пока свободный обзор зажат, никакие чужие данные в камеру не попадают:
         * анимации камеры TACZ (осмотр оружия, тряска, отдача) и роль/крен отбрасываются.
         * После отпускания клавиши подавление плавно снимается (cameraSuppress -> 0),
         * и чужие анимации продолжаются с того состояния, в котором они находятся сейчас.
         *
         * Чужое смещение определяем так: если углы в событии ближе к «ванильным» — их
         * перезаписали (смещение = событие - ванильные), иначе добавили поверх наших
         * (смещение = событие - наши).
         */
        @SubscribeEvent(priority = EventPriority.LOWEST)
        public static void camera(ViewportEvent.ComputeCameraAngles e) {
            if (!active) return;
            var player = Minecraft.getInstance().player;
            if (player == null || e.getCamera().getEntity() != player) return;

            float pt = (float) e.getPartialTick();
            float vanYaw = player.getViewYRot(pt);
            float vanPitch = player.getViewXRot(pt);
            float ourYaw = vanYaw + currentYaw;
            float ourPitch = currentAbsPitch;

            float evYaw = e.getYaw();
            float evPitch = e.getPitch();

            float dYawOurs = Mth.wrapDegrees(evYaw - ourYaw);
            float dYawVan = Mth.wrapDegrees(evYaw - vanYaw);
            float dOurs = dYawOurs * dYawOurs + (evPitch - ourPitch) * (evPitch - ourPitch);
            float dVan = dYawVan * dYawVan + (evPitch - vanPitch) * (evPitch - vanPitch);

            float foreignYaw, foreignPitch;
            if (dVan < dOurs) { // углы перезаписаны другим модом
                foreignYaw = dYawVan;
                foreignPitch = evPitch - vanPitch;
            } else {            // другой мод добавил своё поверх наших
                foreignYaw = dYawOurs;
                foreignPitch = evPitch - ourPitch;
            }

            float keep = 1f - cameraSuppress; // доля чужих данных, допущенная в камеру
            e.setYaw(ourYaw + foreignYaw * keep);
            e.setPitch(Mth.clamp(ourPitch + foreignPitch * keep, -90f, 90f));
            e.setRoll(e.getRoll() * keep);
        }
    }
}
