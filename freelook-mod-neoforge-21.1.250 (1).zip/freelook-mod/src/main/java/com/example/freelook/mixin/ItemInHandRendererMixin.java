package com.example.freelook.mixin;

import com.example.freelook.FreeLookMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Руки и оружие рисуются в пространстве камеры, поэтому при повороте камеры
 * они «приклеены» к ней. На время отрисовки рук (включая оружие TACZ) вращаем
 * матрицу на ту же величину, на которую повернули камеру — руки остаются на месте.
 *
 * Руки не повторяют наклон головы игрока: их «опорный» угол плавно уходит в 0° (горизонт),
 * поэтому при взгляде вниз ствол встаёт в обычное положение, а не смотрит вниз.
 * Чем ниже камера от горизонта, тем ближе руки (прячет «полёт» рук).
 *
 * Матрица: Rx(g(absPitch)) * Ry(dYaw) * Rx(-g(handRef)), затем смещение к камере.
 * g(a) = a * HAND_PITCH_FOLLOW при a > 0 (ниже горизонта), g(a) = a при a <= 0 (выше горизонта).
 */
@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandRendererMixin {

    @Inject(method = "renderHandsWithItems", at = @At("HEAD"))
    private void freelook$begin(float partialTicks, PoseStack poseStack,
                                MultiBufferSource.BufferSource buffer, LocalPlayer player,
                                int light, CallbackInfo ci) {
        poseStack.pushPose();
        if (!FreeLookMod.isActive()) return;
        // ниже горизонта руки менее чувствительны к наклону головы, выше — двигаются как раньше
        poseStack.mulPose(Axis.XP.rotationDegrees(FreeLookMod.handAngle(FreeLookMod.currentAbsPitch)));
        poseStack.mulPose(Axis.YP.rotationDegrees(FreeLookMod.currentYaw));
        poseStack.mulPose(Axis.XP.rotationDegrees(-FreeLookMod.handAngle(FreeLookMod.currentHandRef)));
        float pull = FreeLookMod.currentPull;
        if (pull > 0.001f) {
            // в системе рук +Z — к камере, -Y — вниз, к телу
            poseStack.translate(0f, -FreeLookMod.HAND_PULL_Y * pull, FreeLookMod.HAND_PULL_Z * pull);
        }
    }

    @Inject(method = "renderHandsWithItems", at = @At("RETURN"))
    private void freelook$end(float partialTicks, PoseStack poseStack,
                              MultiBufferSource.BufferSource buffer, LocalPlayer player,
                              int light, CallbackInfo ci) {
        poseStack.popPose();
    }
}
